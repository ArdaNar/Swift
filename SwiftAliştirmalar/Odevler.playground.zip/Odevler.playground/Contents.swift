import UIKit


struct Sicaklik{
    var derece: Double
    var fahrenheit: Double
    
    init(derece: Double){
        self.derece = derece
        fahrenheit = (derece * 1.8) + 32
        
    }
    init(fahrenheit: Double){
        derece = (fahrenheit - 32) / 1.8
        self.fahrenheit = fahrenheit
    }
}
var sicaklik = Sicaklik(fahrenheit: 120)
print(sicaklik.derece)
var sicaklik1 = Sicaklik(derece: 20)
print(sicaklik1.fahrenheit)




func cevre(en: Double, boy: Double){
    var cevre = 2 * (en + boy)
    print(cevre)
}
cevre(en: 10, boy: 23.2)




class FaktoriyelHesaplama{
    func faktoriyel(sayi: Int) -> Int{
        var sonuc = 1
        for i in 1...sayi{
            sonuc = sonuc * i
        }
        return sonuc
    }
}
let faktoriyel = FaktoriyelHesaplama()
print(faktoriyel.faktoriyel(sayi: 5))




class kelime{
    func kelimeAdetiBul(kelime:String, harf:Character){
        var sonuc = 0
        
        for k in kelime{
            if k == harf{
                sonuc += 1
            }
        }
        print("Harf Adeti: \(sonuc)")
    }
}

var deneme2 = kelime()
deneme2.kelimeAdetiBul(kelime: "Arda", harf: "a")




class icAci{
    var toplam = 0
    func kenarSayisi(kenar:Int) -> Int{
        toplam = (kenar - 2) * 180
        return toplam
    }
}
var k = icAci()
k.kenarSayisi(kenar: 3)
print(k.kenarSayisi(kenar: 3))





class maasHesaplama{
    func maas(gun:Int) -> Int{
        var maas = 0
        let mesaiSaati = gun * 8
        
        if mesaiSaati<160{
            maas = mesaiSaati * 10
        }else{
            maas = 1600 + ((mesaiSaati-160) * 20)
        }
        return maas
    }
}

var m = maasHesaplama()
m.maas(gun: 22)
print(m.maas(gun: 22))




class internetUcreti{
    func internet(kota: Int) -> Int{
        var ucret = 0
        if kota>50{
            ucret = 100 + ((kota-50) * 4)
        }else{
            ucret = 100
        }
        return ucret
    }
}

var i = internetUcreti()
i.internet(kota: 100)
print(i.internet(kota: 100))

